# DOM exercise

In this exercise we want to create a button called fetch that returns all the soccer leagues in this API (https://api-football-standings.azharimm.site/leagues).

We have to

1. Create the markup. (It can be really simple just a button)
2. Create a separate js file to solve the problem
3. Get the button element
4. Listen for the click event in the button
5. Fetch the data
6. Console.log of the data we retrieve
7. Display the data in the DOM. Optional


