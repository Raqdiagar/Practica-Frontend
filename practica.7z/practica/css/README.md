# css exercise

In this exercises we will use the file `index.html` to do the questions, so please go to that file to complete the exercise.
